---
name: Arbiter Dark Authority
colors:
  surface: '#131318'
  surface-dim: '#131318'
  surface-bright: '#39383e'
  surface-container-lowest: '#0e0e13'
  surface-container-low: '#1b1b20'
  surface-container: '#1f1f25'
  surface-container-high: '#2a292f'
  surface-container-highest: '#35343a'
  on-surface: '#e4e1e9'
  on-surface-variant: '#ccc3d8'
  inverse-surface: '#e4e1e9'
  inverse-on-surface: '#303036'
  outline: '#958da1'
  outline-variant: '#4a4455'
  surface-tint: '#d2bbff'
  primary: '#d2bbff'
  on-primary: '#3f008e'
  primary-container: '#7c3aed'
  on-primary-container: '#ede0ff'
  inverse-primary: '#732ee4'
  secondary: '#4cd7f6'
  on-secondary: '#003640'
  secondary-container: '#03b5d3'
  on-secondary-container: '#00424e'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#905b00'
  on-tertiary-container: '#ffe1c0'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#eaddff'
  primary-fixed-dim: '#d2bbff'
  on-primary-fixed: '#25005a'
  on-primary-fixed-variant: '#5a00c6'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#131318'
  on-background: '#e4e1e9'
  surface-variant: '#35343a'
typography:
  display-lg:
    fontFamily: Outfit
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Outfit
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Outfit
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
  max-width: 1440px
---

## Brand & Style

The design system is engineered for **Arbiter AI**, a platform where legal precision meets cutting-edge intelligence. The brand personality is **Trustworthy, Intelligent, Powerful, and Precise**. It evokes the feeling of a high-stakes "mission control" center for legal professionals, where data is not just processed, but interrogated.

The visual style is a fusion of **Dark Minimalism** and **Glassmorphism**. It utilizes deep, void-like backgrounds to provide maximum contrast for critical data points, while layered translucent surfaces create a sense of sophisticated hierarchy. Every element is intentional, avoiding decorative clutter in favor of a technical, high-performance aesthetic that commands authority.

## Colors

The palette is anchored in **Deep Space Black (#0a0a0f)** to establish a grounded, authoritative environment. Hierarchy is defined by increasing the luminosity of surfaces: secondary surfaces use **#12121a**, while interactive cards utilize **#1a1a2e**.

**Accents & Semantics:**
- **Royal Purple (#7c3aed):** Used for primary actions and active state pulses.
- **Cyan (#06b6d4):** Used for research highlights and secondary navigation.
- **Gold (#f59e0b):** Reserved for high-value insights and uncertainty warnings.
- **Verified Green (#10b981) / Disputed Red (#ef4444):** Strict semantic indicators for legal truth-claiming.

All accent colors should utilize subtle glow effects (outer glows/dropshadows with low opacity) to simulate an illuminated interface in a dark room.

## Typography

This design system employs a three-tier typeface strategy to balance authority with technicality:

1.  **Outfit (Display):** High-energy, modern geometric sans-serif for headlines. It communicates the forward-thinking nature of AI.
2.  **Inter (Body):** The workhorse for readability. Used for all legal texts, research summaries, and general interface labels.
3.  **JetBrains Mono (Technical):** Used for citations, case numbers, confidence scores, and code-like data. It provides the "research-grade" feel required for verification tasks.

**Constraint:** Never use Outfit for long-form body text. Reserve JetBrains Mono for specific data points to maintain the "mission control" aesthetic without sacrificing legibility.

## Layout & Spacing

The system follows a strict **8px grid** to ensure mathematical precision. 

- **Desktop:** A 12-column fluid grid with 24px gutters. Sidebars for "Agent Status" or "Document Outlines" are fixed at 280px or 320px, with the primary research canvas remaining fluid.
- **Mobile:** A 4-column grid with 20px margins. 
- **Rhythm:** Use generous internal padding within glass cards (minimum 24px) to ensure content breathes and feels premium. Elements should be grouped using proximity rather than heavy lines where possible.

## Elevation & Depth

Depth is achieved through **Glassmorphism** and tonal stacking rather than traditional high-offset shadows.

1.  **Base Layer:** Solid Deep Space Black (#0a0a0f).
2.  **Surface Layer:** Elevated panels with a subtle 1px border (#ffffff at 10% opacity) and a backdrop-blur of 12px.
3.  **Interactive Layer:** Active cards use the secondary surface color (#1a1a2e) with a subtle Royal Purple inner glow for active states.
4.  **Accents:** Critical alerts use "Bloom" lighting—a soft, colored shadow (e.g., Purple or Cyan) with a 20px-40px blur at very low (15%) opacity to simulate light emitting from the screen.

## Shapes

The design system uses **Rounded (0.5rem)** as the default radius. This strikes a balance between the clinical sharpness of legal tools and the modern softness of high-end AI.

- **Standard Elements:** 8px (0.5rem) radius for buttons and input fields.
- **Large Components:** 16px (1rem) for glass cards and containers.
- **Status Indicators:** 100% (pill-shaped) for tags, confidence gauges, and status badges to differentiate them from structural containers.

## Components

**Buttons & Inputs:**
- **Primary:** Royal Purple solid fill with a 50% opacity purple glow on hover.
- **Secondary:** Ghost style with a 1px Cyan border and transparent background.
- **Inputs:** Darker than the surface layer, using a subtle 1px white-border (10% opacity) that pulses Purple on focus.

**Specialized Components:**
- **Confidence Gauges:** Circular, stroke-based rings using the semantic color palette (Green/Gold/Red) to visualize AI certainty.
- **Glass Cards:** Semi-transparent containers for research data. Must feature a top-left light source simulation via a 1px light border.
- **Agent Avatars:** Circular profile images with a glowing ring indicator (Green = Active, Purple = Thinking, Grey = Idle).
- **Pipeline Connectors:** 1px width Cyan lines with a subtle gradient or "marching ants" animation to show data flow between research nodes.
- **Verification Badges:** Small, high-contrast labels using JetBrains Mono, denoting "Source Verified" or "AI Generated."